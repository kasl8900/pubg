<?php
$emailku = 'gopibhai9818@gmail.com';
?>